# Prediction algorithm using ML

import pandas
from sklearn.tree import DecisionTreeClassifier

mobiledata=pandas.read_csv('MobileModel.csv')
#print(mobiledata)

#training data
features=mobiledata.drop(columns=['MobileModel'])
labels=mobiledata['MobileModel']

#build a model
model=DecisionTreeClassifier()
model.fit(features,labels)

#test data and predict
result=model.predict([[1,55,1],[2,52,1]])
print(result)

